---
name: Feature request
about: Propose a new feature for this library
title: ''
labels: Feature request
assignees: ''

---

**Describe the proposed feature**

**What other libraries (C++ or other) have this feature?**

**Include a code fragment with sample data that illustrates the use of this feature**
