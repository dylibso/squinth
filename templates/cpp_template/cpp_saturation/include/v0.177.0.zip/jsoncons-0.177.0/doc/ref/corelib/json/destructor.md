### `jsoncons::basic_json::basic_json`

```cpp
~basic_json() noexcept;
```

Destroys all values and deletes all memory allocated for strings, arrays, and objects.


