### jsoncons::spaces_option

```cpp
enum class spaces_option : uint8_t 
{
    no_spaces=0,
    space_after,
    space_before,
    space_before_and_after
};
```

