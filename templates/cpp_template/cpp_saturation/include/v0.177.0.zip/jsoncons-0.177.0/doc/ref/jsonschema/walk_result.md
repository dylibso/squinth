### jsoncons::jsonschema::walk_result 

```cpp
enum class walk_result {
   advance,
   abort
};
```

