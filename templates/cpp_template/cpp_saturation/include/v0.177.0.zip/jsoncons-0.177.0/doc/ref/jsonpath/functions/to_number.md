### to_number

```
number to_number(string|number value)
```

If string, returns the parsed number. 
If number, returns the passed in value.

It is a type error if

- the provided value is not a string or number

- the string cannot be parsed as a number

### Examples


